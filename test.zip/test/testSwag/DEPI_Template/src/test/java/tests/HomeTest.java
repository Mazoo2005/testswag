package tests;

public class HomeTest extends TestBase{
}
